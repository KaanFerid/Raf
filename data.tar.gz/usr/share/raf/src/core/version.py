# This file is automatically updated by Git hooks.
__version__ = "1.3.1"
